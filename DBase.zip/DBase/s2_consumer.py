from time import sleep
from datetime import datetime
import json
import logging
from connections import DatabaseConnections
from kafka.errors import KafkaError, NoBrokersAvailable, NodeNotReadyError
import socket

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MessageProcessor:
    def __init__(self, db):
        self.db = db
        self.max_retries = 3
        self.dead_letter_queue = []

    def log_to_elasticsearch(self, message_type, content, status="processed", metadata=None):
        try:
            doc = {
                "message_type": message_type,
                "content": str(content),
                "timestamp": datetime.now().isoformat(),
                "status": status,
                "metadata": metadata or {}
            }
            # Use o mesmo índice que definimos na conexão
            self.db.es_client.index(index="cypher-messages", body=doc)
        except Exception as e:
            logger.error(f"Failed to log to Elasticsearch: {e}")

    def process_with_retry(self, message):
        retry_count = 0
        last_error = None
        
        while retry_count < self.max_retries:
            try:
                if isinstance(message.timestamp, int):
                    msg_timestamp = datetime.fromtimestamp(message.timestamp / 1000)  
                else:
                    msg_timestamp = message.timestamp  

                self.log_to_elasticsearch(
                    "kafka_message_received",
                    message.value,
                    "processing",
                    {
                        "topic": message.topic,
                        "partition": message.partition,
                        "offset": message.offset,
                        "retry_count": retry_count
                    }
                )
                
                # Processa a mensagem
                if message.topic == "user-actions":
                    self.handle_user_action(message.value)
                elif message.topic == "recommendation-requests":
                    self.handle_recommendation_request(message.value)
                
                # Calcula tempo de processamento corretamente
                processing_time_ms = (datetime.now() - msg_timestamp).total_seconds() * 1000
                
                self.log_to_elasticsearch(
                    "kafka_message_processed",
                    message.value,
                    "completed",
                    {
                        "topic": message.topic,
                        "processing_time_ms": processing_time_ms
                    }
                )
                return True
                
            except Exception as e:
                last_error = e
                retry_count += 1
                logger.error(f"Attempt {retry_count} failed for message {message.offset}: {str(e)}")
                sleep(2 ** retry_count)
        
        self.handle_failed_message(message, last_error)
        return False

    def handle_failed_message(self, message, error):
        error_data = {
            "original_message": message.value,
            "topic": message.topic,
            "partition": message.partition,
            "offset": message.offset,
            "error": str(error),
            "timestamp": datetime.now().isoformat(),
            "retries_exhausted": True
        }
        
        # Add to dead letter queue
        self.dead_letter_queue.append(error_data)
        
        # Log to Elasticsearch
        self.log_to_elasticsearch(
            "kafka_message_failed",
            message.value,
            "error",
            {
                "error": str(error),
                "retries": self.max_retries,
                "dead_letter": True
            }
        )
        
        # Optionally write to a dead letter topic or file
        try:
            with open("kafka_dead_letter.log", "a") as f:
                f.write(json.dumps(error_data) + "\n")
        except Exception as e:
            logger.error(f"Failed to write to dead letter log: {e}")

    def handle_recommendation_request(self, message_data):
        try:
            if isinstance(message_data, str):
                message_data = json.loads(message_data)

            user_id = message_data.get("data", {}).get("user_id")
            current_song_id = message_data.get("data", {}).get("current_song")

            if not user_id or not current_song_id:
                raise ValueError("Dados incompletos: user_id ou current_song ausentes")

            current_song = self.db.mongo_db.songs.find_one({"_id": current_song_id})
            if not current_song:
                raise ValueError(f"Música atual '{current_song_id}' não encontrada")

            genre = current_song.get("genre")
            artist = current_song.get("artist")

            query = {
                "$and": [
                    {"_id": {"$ne": current_song_id}},
                    {"$or": [
                        {"genre": genre},
                        {"artist": artist}
                    ]}
                ]
            }
            recommendations = list(
                self.db.mongo_db.songs.find(query).limit(5)
            )

            rec_doc = {
                "user_id": user_id,
                "based_on": {
                    "song_id": current_song_id,
                    "genre": genre,
                    "artist": artist
                },
                "recommendations": recommendations,
                "created_at": datetime.now().isoformat()
            }

            self.db.mongo_db.recommendations.insert_one(rec_doc)

            self.db.cache_recommendation(user_id, recommendations)

            self.log_to_elasticsearch(
                "recommendation_processed",
                rec_doc,
                status="completed",
                metadata={"user_id": user_id, "recommended_count": len(recommendations)}
            )

        except Exception as e:
            self.log_to_elasticsearch(
                "recommendation_processing_failed",
                str(message_data),
                status="error",
                metadata={"error": str(e)}
            )
            raise

    def handle_user_action(self, message_data):
        try:
            if not message_data:
                raise ValueError("Mensagem vazia recebida")
            message_data = json.loads(message_data)

            action_type = message_data.get("type")
            data = message_data.get("data", {})

            if action_type == "user_created":
                # Garante que o usuário seja inserido em PostgreSQL (CockroachDB)
                cursor = self.db.pg_conn.cursor()
                cursor.execute(
                    "INSERT INTO users (id, name, email, preferences, spotify_id) VALUES (%s, %s, %s, %s, %s)",
                    (
                        data.get("user_id"),
                        data.get("name"),
                        data.get("email"),
                        json.dumps(data.get("preferences", [])),
                        data.get("spotify_id")
                    )
                )
                self.db.pg_conn.commit()

            elif action_type == "song_added":
                # Reinsere a música no MongoDB caso necessário
                if not self.db.mongo_db.songs.find_one({"_id": data["_id"]}):
                    self.db.mongo_db.songs.insert_one(data)

            else:
                raise ValueError(f"Ação não reconhecida: {action_type}")

            # Loga sucesso
            self.log_to_elasticsearch(
                "user_action_processed",
                message_data,
                "completed",
                {"action_type": action_type}
            )

        except Exception as e:
            self.log_to_elasticsearch(
                "user_action_failed",
                str(message_data),
                "error",
                {"error": str(e), "action_type": message_data.get("type")}
            )
            raise



def consume_messages():
    db = DatabaseConnections()
    processor = MessageProcessor(db)
    
    retry_count = 0
    max_retries = 5
    base_delay = 5  # segundos
    
    while True:
        consumer = None
        try:
            consumer = db.get_kafka_consumer(["user-actions", "recommendation-requests"])
            if not consumer:
                raise KafkaError("Failed to initialize Kafka consumer")
            
            retry_count = 0  # Resetar contador após conexão bem-sucedida
            
            while True:
                try:
                    messages = consumer.poll(timeout_ms=5000)
                    
                    if not messages:
                        continue
                        
                    for topic_partition, msg_batch in messages.items():
                        for message in msg_batch:
                            success = processor.process_with_retry(message)
                            if success:
                                consumer.commit()
                            else:
                                logger.error(f"Message processing failed permanently: {message.offset}")
                                
                except (KafkaError, socket.timeout) as e:
                    logger.error(f"Erro durante o consumo: {str(e)}")
                    if isinstance(e, (NoBrokersAvailable, NodeNotReadyError)):
                        break  # Reconectar
                    sleep(1)
                    
        except Exception as e:
            logger.error(f"Erro no consumidor principal: {str(e)}")
            retry_count += 1
            
            if retry_count >= max_retries:
                logger.error("Número máximo de tentativas excedido. Encerrando...")
                raise
            
            delay = base_delay * (2 ** retry_count)  # Backoff exponencial
            logger.info(f"Tentando reconectar em {delay} segundos...")
            sleep(delay)
            
        finally:
            if consumer:
                try:
                    consumer.close()
                except:
                    pass

if __name__ == "__main__":
    consume_messages()